import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Boolean isDebugOrTrace(Message message) { 
               def isDebug = false;
               
               def processingLogConfiguration = message.getProperty("SAP_MessageProcessingLogConfiguration") as String;
               isDebug = processingLogConfiguration.contains("logLevel=DEBUG") || processingLogConfiguration.contains("logLevel=TRACE")
               
               return isDebug; 
}

def Message processJson(Message message)
{
	// Get message content
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;


	// Get Props
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	// Get Headers
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	// Set Message
	String attachmentMessage = "\n Properties \n ----------   \n" + propertiesAsString +
							   "\n Headers \n ----------   \n" + headersAsString +
							   "\n Body \n ----------  \n\n" + body
																	
	invokeMessageLogger(message,"MonitoringContent.json",attachmentMessage)
    
	return message
}

def Message processJsonSplunk (Message message)
{
	// Get message content
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;


	// Get Props
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	// Get Headers
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	// Set Message
	String attachmentMessage = "\n Properties \n ----------   \n" + propertiesAsString +
							   "\n Headers \n ----------   \n" + headersAsString +
							   "\n Body \n ----------  \n\n" + body
																	
	invokeMessageLogger(message,"SplunkRequest.json",attachmentMessage)
    
	return message
}

def Message processXML(Message message)
{
	// Get message content
	def body = message.getBody(java.lang.String) as String;
	def headers = message.getHeaders() as Map<String, Object>;
	def properties = message.getProperties() as Map<String, Object>;


	// Get Props
	def propertiesAsString ="\n";
	properties.each{ it -> propertiesAsString = propertiesAsString + "${it}" + "\n" };
	// Get Headers
	def headersAsString ="\n";
	headers.each{ it -> headersAsString = headersAsString + "${it}" + "\n" };
	// Set Message
	String attachmentMessage = "\n Properties \n ----------   \n" + propertiesAsString +
							   "\n Headers \n ----------   \n" + headersAsString +
							   "\n Body \n ----------  \n\n" + body
																	
	invokeMessageLogger(message,"MonitoringContent.xml",attachmentMessage)
    
	return message
}

/***
 * Helper function: invoke the Message Logger and create attachment
 */
def void invokeMessageLogger(Message message, String title, String attachmentMessage)
{
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null)
	{
	 messageLog.addAttachmentAsString(title, attachmentMessage,"text/plain");
	}
}

