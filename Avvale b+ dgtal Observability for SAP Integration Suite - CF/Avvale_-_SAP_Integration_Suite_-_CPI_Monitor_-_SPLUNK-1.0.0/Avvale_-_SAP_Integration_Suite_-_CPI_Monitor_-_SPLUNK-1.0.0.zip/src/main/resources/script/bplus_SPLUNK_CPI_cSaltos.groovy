import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.json.*;

def Message processData(Message message) {
	
    def body = message.getBody(String);
	def bodyJSON = new JsonSlurper().parseText(body);
	
	def date = bodyJSON.execution.monitoringStartAt;
	message.setProperty("url_date", date.substring(0,10));
	message.setHeader("Content-Type","application/x-ndjson");

	def salida = "[\r\n";
	def MetaData = "";
	def CommonEventData = 
				"\r\n \"execution.executedAt\":\"" + bodyJSON.execution.executedAt + "\","+ 
				" \"execution.monitoringEndAt\":\"" + bodyJSON.execution.monitoringEndAt + "\","+ 
				" \"execution.monitoringStartAt\":\"" + bodyJSON.execution.monitoringStartAt + "\","+ 
				" \"execution.type\":\"" + bodyJSON.execution.type + "\","+ 
				" \"execution.version\":\"" + bodyJSON.execution.version + "\","+ 
				
				" \"system.name\":\"" + bodyJSON.system.name + "\","+ 
				" \"tenant.code\":\"" + bodyJSON.tenant.code + "\", \r\n " ;
	
    def resultJSON ;
    def jsonFormateado;
    

	////////////////////////////////////////////////
    //////////////////// Tenant ////////////////////
	////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"scpi_summary\"," + 
				" \"source\":\"scpi_summary\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n" ;
				
	def EventDataTenant = "{" + CommonEventData +
				" \"artifactsOverview.error\":\"" + bodyJSON.artifactsOverview.error + "\","+ 
				" \"artifactsOverview.started\":\"" + bodyJSON.artifactsOverview.started + "\","+ 
				" \"artifactsOverview.starting\":\"" + bodyJSON.artifactsOverview.starting + "\","+ 
				" \"artifactsOverview.stopping\":\"" + bodyJSON.artifactsOverview.stopping + "\","+ 
				
				" \"messageOverview.completed\":\"" + bodyJSON.messageOverview.completed + "\","+ 
				" \"messageOverview.error\":\"" + bodyJSON.messageOverview.error + "\","+ 
				" \"messageOverview.escalated\":\"" + bodyJSON.messageOverview.escalated + "\","+ 
				" \"messageOverview.failed\":\"" + bodyJSON.messageOverview.failed + "\","+ 
				" \"messageOverview.numberDays\":\"" + bodyJSON.messageOverview.numberDays + "\","+ 
				" \"messageOverview.processing\":\"" + bodyJSON.messageOverview.processing + "\","+ 
				" \"messageOverview.retry\":\"" + bodyJSON.messageOverview.retry + "\""+ 
				"}";
				
	def BlockDataTenant = MetaData + EventDataTenant + "}";
	
    resultJSON = new JsonSlurper().parseText(BlockDataTenant);
    jsonFormateado = JsonOutput.toJson(resultJSON);
    
	salida += " " + jsonFormateado ;
	
	
	/////////////////////////////////////////////////////////
	/////////////////////// Artifacts ///////////////////////
	/////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"scpi_artifacts\"," + 
				" \"source\":\"scpi_artifacts\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.runtimeArtifactsDetail.each{ ad ->
	
    	salida += "," + "\r\n";
	
		def EventData = "{" + CommonEventData +
				" \"runtimeArtifactsDetail.deployedby\":\"" + ad.deployedby + "\","+ 
				" \"runtimeArtifactsDetail.deployedon\":\"" + ad.deployedon + "\","+ 
				" \"runtimeArtifactsDetail.id\":\"" + ad.id + "\","+ 
				" \"runtimeArtifactsDetail.name\":\"" + ad.name + "\","+ 
				" \"runtimeArtifactsDetail.status\":\"" + ad.status + "\","+ 
				" \"runtimeArtifactsDetail.type\":\"" + ad.type + "\","+ 
				" \"runtimeArtifactsDetail.version\":\"" + ad.version + "\""+ 
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	////////////////////////////////////////////////////////
	/////////////////////// Messages ///////////////////////
	////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"scpi_messages\"," + 
				" \"source\":\"scpi_messages\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.messagesDetail.each{ md ->
	
    	salida += "," + "\r\n";
	
        if ((md.errorDetail != null) && (!md.errorDetail.equals("")))
        {
            byte[] decoded_errorDetail = md.errorDetail.decodeBase64()
	        String decoded = new String(decoded_errorDetail)
	        decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
	        md.errorDetail = decoded
        }
	
		def EventData = "{" + CommonEventData +
				" \"messagesDetail.messageGuid\":\"" + md.messageGuid + "\","+ 
				" \"messagesDetail.correlationId\":\"" + md.correlationId + "\","+ 
				" \"messagesDetail.logStart\":\"" + md.logStart + "\","+ 
				" \"messagesDetail.logEnd\":\"" + md.logEnd + "\","+ 
				" \"messagesDetail.integrationFlowName\":\"" + md.integrationFlowName + "\","+ 
				" \"messagesDetail.customStatus\":\"" + md.customStatus + "\","+ 
				" \"messagesDetail.alternateWebLink\":\"" + md.alternateWebLink + "\","+ 
				" \"messagesDetail.integrationArtifactId\":\"" + md.integrationArtifactId + "\","+ 
				" \"messagesDetail.integrationArtifactName\":\"" + md.integrationArtifactName + "\","+ 
				" \"messagesDetail.integrationArtifactType\":\"" + md.integrationArtifactType + "\","+ 
				" \"messagesDetail.integrationArtifactPackageId\":\"" + md.integrationArtifactPackageId + "\","+ 
				" \"messagesDetail.integrationArtifactPackageName\":\"" + md.integrationArtifactPackageName + "\","+ 
				" \"messagesDetail.transactionId\":\"" + md.transactionId + "\","+ 
				" \"messagesDetail.previousComponentName\":\"" + md.previousComponentName + "\","+ 
				" \"messagesDetail.localComponentName\":\"" + md.localComponentName + "\","+ 
				" \"messagesDetail.originComponentName\":\"" + md.originComponentName + "\","+ 
				" \"messagesDetail.errorDetail\":\"" + md.errorDetail + "\""+ 
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	////////////////////////////////////////////////////////////
	/////////////////////// Certificates ///////////////////////
	////////////////////////////////////////////////////////////
	
	MetaData = "{ \"index\":\"scpi_certificates\"," + 
				" \"source\":\"scpi_certificates\"," + 
				" \"sourcetype\":\"_json\"," + 
				" \"event\":\r\n " ;
	
	bodyJSON.certificatesDetail.each{ cd ->
	
    	salida += "," + "\r\n";
	
		if ((cd.subjectDN != null) && (!cd.subjectDN.equals("")))
		{
			byte[] decoded_sdn = cd.subjectDN.decodeBase64()
			String decoded = new String(decoded_sdn)
			decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
			cd.subjectDN = decoded
		}
		
		if ((cd.issuerDN != null) && (!cd.issuerDN.equals("")))
		{
			byte[] decoded_idn = cd.issuerDN.decodeBase64()
			String decoded = new String(decoded_idn)
			decoded = decoded.replaceAll("[^a-zA-Z0-9 .,=]", "")
			cd.issuerDN = decoded
		}
	
		def EventData = "{" + CommonEventData +
				" \"certificatesDetail.alias\":\"" + cd.alias + "\","+ 
		//		" \"certificatesDetail.keystoreView\":\"" + cd.keystoreView + "\","+ 
		//		" \"certificatesDetail.keytype\":\"" + cd.keytype + "\","+ 
		//		" \"certificatesDetail.keysize\":\"" + cd.keysize + "\","+ 
				" \"certificatesDetail.validNotBefore\":\"" + cd.validNotBefore + "\","+ 
				" \"certificatesDetail.validNotAfter\":\"" + cd.validNotAfter + "\","+ 
		//		" \"certificatesDetail.serialNumber\":\"" + cd.serialNumber + "\","+ 
		//		" \"certificatesDetail.signatureAlgorithm\":\"" + cd.signatureAlgorithm + "\","+ 
				" \"certificatesDetail.subjectDN\":\"" + cd.subjectDN + "\","+ 
				" \"certificatesDetail.issuerDN\":\"" + cd.issuerDN + "\","+ 
		//		" \"certificatesDetail.fingerprintSha1\":\"" + cd.fingerprintSha1 + "\","+ 
		//		" \"certificatesDetail.fingerprintSha256\":\"" + cd.fingerprintSha256 + "\","+ 
		//		" \"certificatesDetail.fingerprintSha512\":\"" + cd.fingerprintSha512 + "\","+ 
		//		" \"certificatesDetail.lastModifiedBy\":\"" + cd.lastModifiedBy + "\","+ 
		//		" \"certificatesDetail.lastModifiedTime\":\"" + cd.lastModifiedTime + "\","+ 
		//		" \"certificatesDetail.createdBy\":\"" + cd.createdBy + "\","+ 
		//		" \"certificatesDetail.createdTime\":\"" + cd.createdTime + "\","+ 
		//		" \"certificatesDetail.status\":\"" + cd.status + "\","+ 
				" \"certificatesDetail.relatedIflows\":\"" + cd.relatedIflows + "\","+ 
		//		" \"certificatesDetail.type\":\"" + cd.type + "\","+ 
		//		" \"certificatesDetail.owner\":\"" + cd.owner + "\","+ 
		//		" \"certificatesDetail.version\":\"" + cd.version + "\""+ 
				"}";
				
		def BlockData = MetaData + EventData + "}";
		
		resultJSON = new JsonSlurper().parseText(BlockData);
		jsonFormateado = JsonOutput.toJson(resultJSON);
    
    	salida += " " + jsonFormateado ;
	}
	
	
	salida += "\r\n" + "]" ;
    message.setBody(salida);
    return message;
}




