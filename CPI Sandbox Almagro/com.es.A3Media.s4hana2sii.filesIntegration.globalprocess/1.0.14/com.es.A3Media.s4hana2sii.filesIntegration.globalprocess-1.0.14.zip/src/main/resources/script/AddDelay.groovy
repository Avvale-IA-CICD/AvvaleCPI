import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

def Message processData(Message message) {
   //Read desired delay with respect to Altas process (in seconds)
   def delay = message.getProperties().get("DelayBetweenBatches").toInteger()*1000
   
   //Sleep for specified time
   sleep(delay)
   return message;
}