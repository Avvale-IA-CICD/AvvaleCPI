import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Read contents of the file (format irrelevant)
    def body = message.getBody(java.lang.String) as String
    
    //If nothing has been read, stop looping call
    if(body) message.setProperty("ContinueReading","true")
    else message.setProperty("ContinueReading","false")
    
    //Monitoring: save file name as custom header
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog?.addCustomHeaderProperty("Filename", message.getHeaders().get("CamelFileName"))
    
    //Save filename in property ArchiveName for archiving purposes
    message.setProperty("ArchiveName", message.getHeaders().get("CamelFileName"))
    return message;
}