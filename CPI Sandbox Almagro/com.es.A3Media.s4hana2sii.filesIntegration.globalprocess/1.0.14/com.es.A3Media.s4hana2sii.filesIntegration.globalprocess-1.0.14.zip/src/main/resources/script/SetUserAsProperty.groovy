import com.sap.gateway.ip.core.customdev.util.Message
import groovy.util.XmlSlurper
import groovy.xml.XmlUtil
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi
import com.sap.it.api.securestore.*
import com.sap.it.api.keystore.*

Message processData(Message message) {

    //New instance of SecureStoreService (to access credentials)
    def secureStorageService = ITApiFactory.getService(SecureStoreService.class, null)


    //Read alias of the secure parameter containing the user
    def secureParameterAlias = message.getProperties().get("SFTP_SERES_SECUREPARAMETER")

    //Fetch the secure parameter defined in the property, read content, set as property to use in SFTP Receiver adapter
     try{
        def secureParameter = secureStorageService.getUserCredential(secureParameterAlias)
        def user = secureParameter.getPassword().toString()
        message.setProperty("SFTP_SERES_USERNAME", user)
    }
    catch(Exception exc){}
    return message
}