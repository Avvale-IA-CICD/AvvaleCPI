import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
   //Read desired delay with respect to Altas process (in seconds)
   def delay = message.getProperties().get("DelayBetweenBatches").toInteger()*1000
   
   //Read property that reveals how many files have been processed
   def numFiles = message.getProperties().get("CamelLoopIndex").toInteger()
   
   //Sleep for specified time as long as files have been read; if not, continue without delay
   if(numFiles>0) sleep(delay)
   return message;
}