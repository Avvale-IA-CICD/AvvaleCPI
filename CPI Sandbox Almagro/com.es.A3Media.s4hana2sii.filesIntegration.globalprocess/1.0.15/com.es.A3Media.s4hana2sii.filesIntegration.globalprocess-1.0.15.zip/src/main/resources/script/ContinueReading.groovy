import com.sap.gateway.ip.core.customdev.util.Message;

def Message processData(Message message) {
    //Read contents of the file (format irrelevant)
    def body = message.getBody(java.lang.String) as String
    def filenamePattern = message.getProperties().get("FilenamePattern")
    def camelFilename = message.getHeaders().get("CamelFileName")
    
    //If nothing has been read, stop looping call
    if(body) message.setProperty("ContinueReading","true")
    else message.setProperty("ContinueReading","false")
    
    //Monitoring: save file name as custom header
    try {
        def messageLog = messageLogFactory.getMessageLog(message)
        if(filenamePattern!=camelFilename) {
            messageLog?.addCustomHeaderProperty("Filename", camelFilename)   
        }
    }
    catch(Exception exc) {
        //In case of failure, do nothing; the process should not be affected
        //because monitoring failed for some reason
    }
    
    
    //Save filename in property ArchiveName for archiving purposes
    message.setProperty("ArchiveName", camelFilename)
    return message;
}