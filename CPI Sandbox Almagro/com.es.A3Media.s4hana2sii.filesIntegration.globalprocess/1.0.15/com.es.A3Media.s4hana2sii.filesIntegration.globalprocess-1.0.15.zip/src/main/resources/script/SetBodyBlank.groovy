import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;

// This Groovy is necessary because the body has to be blank for every
// iteration. Setting the body blank serves the following logic:
//    1. Body is blank at this step
//    2. The SFTP Adapter attempts to read another file
//      2.1 A file is read -> the body is replaced with it; non blank body means we continue
//      2.2 A file is not read -> the body stays blank; blank body means we stop reading
// If the body is not set as a blank here, once we read all the files,
// there is no way to decide when to stop the iterative process. The iterative process
// is controlled by a flag (a property called ContinueReading) that is disabled once the
// body is blank.

def Message processData(Message message) {
    message.setBody("")
    return message;
}