import com.sap.gateway.ip.core.customdev.util.Message
import java.net.URLClassLoader

def Message processData(Message message) {
    def urlsList = []
    def errorMessage = ""
    
    try {
        // Try to cast the current classloader to URLClassLoader to get URLs
        def classLoader = this.getClass().getClassLoader()
        
        if (classLoader instanceof URLClassLoader) {
            // Retrieve the URLs from the classloader
            def urls = ((URLClassLoader) classLoader).getURLs()
            urls.each { url ->
                urlsList << url.toString()
            }
        } else {
            errorMessage = "ClassLoader is not an instance of URLClassLoader."
        }
    } catch (Exception e) {
        errorMessage = "Error accessing classloader URLs: ${e.message}"
    }

    // Join the URLs into a single string or capture the error message
    def result = urlsList ? urlsList.join("\n") : errorMessage
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("ClassLoaderURLs", result, "text/plain")
    message.setBody(result)

    return message
}
