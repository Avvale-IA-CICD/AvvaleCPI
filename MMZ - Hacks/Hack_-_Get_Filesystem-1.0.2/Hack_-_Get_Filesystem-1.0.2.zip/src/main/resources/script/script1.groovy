import com.sap.gateway.ip.core.customdev.util.Message
import java.io.File

def Message processData(Message message) {
    // Define the root directory for the filesystem tree (modify as needed)
    def rootDirPath = "/home/vcap"

    // List to hold each file and directory path
    def paths = []

    // Define a closure for recursively building the paths list
    def buildPaths
    buildPaths = { File dir, String parentPath ->
        if (dir.exists()) {
            // Construct the current path
            def currentPath = parentPath ? "${parentPath}/${dir.getName()}" : dir.getName()
            paths << '/home/' + currentPath

            // If it's a directory, recursively add each subdirectory and file
            if (dir.isDirectory()) {
                dir.listFiles().each { file ->
                    buildPaths(file, currentPath)  // Recursively process each item
                }
            }
        }
    }

    // Start building the paths from the specified root directory
    buildPaths(new File(rootDirPath), "")

    // Join the paths into CSV format
    def csvOutput = paths.join("\n")

    // Set the CSV output in the message body
    message.setBody(csvOutput)
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("FileSystemFolders", csvOutput, "text/plain")
    
    return message
}