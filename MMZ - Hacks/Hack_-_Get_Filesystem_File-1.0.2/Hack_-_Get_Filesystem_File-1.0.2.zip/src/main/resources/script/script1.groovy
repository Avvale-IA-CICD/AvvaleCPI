import com.sap.gateway.ip.core.customdev.util.Message
import java.io.File
import java.nio.file.Files
import java.nio.file.Paths

def Message processData(Message message) {
    // Retrieve the query parameters from the CamelHttpQuery header
    def queryParams = message.getHeaders().get("CamelHttpQuery")
    def filePath = ""

    if (queryParams) {
        // Split query parameters and find the value of FilePath
        queryParams.split("&").each { param ->
            def keyValue = param.split("=")
            if (keyValue[0] == "FilePath") {
                filePath = keyValue[1]
            }
        }
    }
    message.setHeader("filePath", filePath)

    // If FilePath is not provided or is empty
    if (!filePath) {
        message.setBody("Error: FilePath query parameter is missing.")
        message.setHeader("CamelHttpResponseCode", 400)  // Bad Request
        return message
    }

    // Construct the file object from the filePath
    def file = new File(filePath)
    
    // Check if the file exists
    if (!file.exists()) {
        message.setBody("Error: File not found.")
        message.setHeader("CamelHttpResponseCode", 404)  // Not Found
        return message
    }

    // Set HTTP response headers for file download
    message.setHeader("Content-Type", "application/octet-stream")  // Default binary type for files
    message.setHeader("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"")
    message.setHeader("Content-Length", file.length().toString())

    // Read the file content and set it as the response body
    byte[] fileBytes = Files.readAllBytes(Paths.get(filePath))
    message.setBody(fileBytes)

    // Set the successful response code (200 OK)
    message.setHeader("CamelHttpResponseCode", 200)

    return message
}
