import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.securestore.UserCredential
import com.sap.it.api.keystore.KeystoreService
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Base64

def Message processData(Message message) {
    // Retrieve alias and type from message properties
    def alias = message.getHeaders().get("entry_alias") // Property name for alias
    def entryType = message.getHeaders().get("entry_type") // Property name for type (e.g., "OAuth", "UserCredential", "SecureParameter", "KeyPair")

    def result = ""
    
    try {
        // Handle different types of entries based on the provided entry type
        switch (entryType) {
            case "OAuthCC":
                result = retrieveOAuthCredentials(alias)
                break
            case "UserCredential":
                result = retrieveUserCredential(alias)
                break
            case "SecureParameter":
                result = retrieveSecureParameter(alias)
                break
            case "KeyPair":
                result = retrieveKeyPair(alias)
                break
            default:
                result = "Unsupported entry type: ${entryType}"
        }
    } catch (Exception e) {
        result = "Error retrieving entry: ${e.message}"
    }

    // Set the result in the message body
    message.setBody(result)
    return message
}

// Function to retrieve OAuth credentials
def retrieveOAuthCredentials(alias) {
    def secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
    UserCredential oauthCredential = secureStoreService.getUserCredential(alias)
    
    if (oauthCredential != null) {
        def clientId = oauthCredential.getUsername()
        def clientSecret = oauthCredential.getPassword()
        return "OAuthClientID: ${clientId}\nOAuthClientSecret: ${clientSecret}"
    } else {
        return "OAuth credentials not found for alias: ${alias}"
    }
}

// Function to retrieve user credentials
def retrieveUserCredential(alias) {
    def secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
    UserCredential userCredential = secureStoreService.getUserCredential(alias)
    
    if (userCredential != null) {
        def username = userCredential.getUsername()
        def password = userCredential.getPassword()
        return "Username: ${username}\nPassword: ${password}"
    } else {
        return "User credential not found for alias: ${alias}"
    }
}

// Function to retrieve a secure parameter
def retrieveSecureParameter(alias) {
    def secureStoreService = ITApiFactory.getService(SecureStoreService.class, null)
    UserCredential userCredential = secureStoreService.getUserCredential(alias)
    def secParam = userCredential.getPassword()
    if (secParam != null) {
        return "Secure Parameter: ${secParam}"
    } else {
        return "Secure parameter not found for alias: ${alias}"
    }
}

// Function to retrieve key pair (private key and certificate)
def retrieveKeyPair(alias) {
    def keystoreService = ITApiFactory.getService(KeystoreService.class, null)
    PrivateKey privateKey = keystoreService.getKey(alias) as PrivateKey
    X509Certificate certificate = keystoreService.getCertificate(alias) as X509Certificate
    
    if (privateKey != null && certificate != null) {
        // Encode private key and certificate in PEM format
        def privateKeyPem = "-----BEGIN PRIVATE KEY-----\n" +
                            Base64.getEncoder().encodeToString(privateKey.getEncoded()).toList().collate(64)*.join("").join("\n") +
                            "\n-----END PRIVATE KEY-----\n"
        def certificatePem = "-----BEGIN CERTIFICATE-----\n" +
                             Base64.getEncoder().encodeToString(certificate.getEncoded()).toList().collate(64)*.join("").join("\n") +
                             "\n-----END CERTIFICATE-----\n"
        
        return "${privateKeyPem}\n${certificatePem}"
    } else {
        return "Key pair not found for alias: ${alias}"
    }
}