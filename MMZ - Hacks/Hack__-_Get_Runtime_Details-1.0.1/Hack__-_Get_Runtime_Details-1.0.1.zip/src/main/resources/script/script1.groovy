import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def output = new StringBuilder()

    // Retrieve and print JVM properties
    output.append("JVM Properties:\n")
    System.getProperties().each { key, value ->
        output.append("${key} = ${value}\n")
    }

    // Retrieve and print Groovy version
    try {
        def groovyVersion = GroovySystem.getVersion()
        output.append("\nGroovy Version: ${groovyVersion}\n")
    } catch (Exception e) {
        output.append("\nGroovy Version: Unable to retrieve version (${e.message})\n")
    }

    // Attempt to retrieve and print Camel version (CPI uses Camel internally)
    try {
        def camelVersion = org.apache.camel.CamelContext.class.getPackage().getImplementationVersion()
        output.append("\nCamel Version: ${camelVersion}\n")
    } catch (Exception e) {
        output.append("\nCamel Version: Unable to retrieve version (${e.message})\n")
    }

    // Set the output in the message body
    message.setBody(output.toString())
    def messageLog = messageLogFactory.getMessageLog(message)
    messageLog.addAttachmentAsString("SystemDetails", output.toString(), "text/plain")
    
    return message
}

