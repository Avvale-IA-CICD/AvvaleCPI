import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def Message processData(Message message) {
    // Obtener la fecha y hora actual en UTC
    def currentDate = new Date()
    
    // Definir el formato de salida
    def sdf = new SimpleDateFormat("dd.MM.yyyy-HH:mm:ss")
    
    // Establecer la zona horaria a CET/CEST
    sdf.setTimeZone(TimeZone.getTimeZone("Europe/Madrid"))
    
    // Formatear la fecha
    def formattedDate = sdf.format(currentDate)
    
    // Añadir la fecha formateada a los headers o propiedades del mensaje
    message.setHeader("formattedDate", formattedDate)
    
    return message
}