import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.ITApiFactory
import com.sap.it.api.securestore.SecureStoreService
import com.sap.it.api.ccs.adapter.CloudConnectorContext
import com.sap.it.api.ccs.adapter.CloudConnectorProperties
import com.sap.it.api.ccs.adapter.ConnectionType
import groovy.json.JsonBuilder

import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Proxy
import java.net.URL
import java.util.concurrent.CompletableFuture

import java.text.SimpleDateFormat
import java.util.Date
import java.util.TimeZone

def Message infoStep1(Message message) {
    return logElk("INFO","Mensaje Recibido!", message)
}

def Message infoStep2(Message message) {
    return logElk("INFO","Mensaje Firmado!", message)
}

def Message infoStep3(Message message) {
    return logElk("INFO","Mensaje Archivado!", message)
}

def Message infoStep4(Message message) {
    return logElk("INFO", "Notificacion Enviada!", message)
}

def Message infoStep5(Message message) {
    return logElk("INFO", "Mail Enviado!", message)
}

def Message infoStep6(Message message) {
    return logElk("INFO", "Envio SFTP Mandingo Procesado!", message)
}

def Message infoStep7(Message message) {
    return logElk("INFO", "Bapiret Procesada!", message)
}

def Message errorStep(Message message) {
    return logElk("ERROR", "Error Procesando Mensaje!", message)
}

def makeAsyncPostRequest(boolean useProxy, String urlString, String payload, String elkAuthHeader, String ccAuthHeader, String locationId, String ccHost, int ccPort) {
    CompletableFuture.runAsync {
        try {
            URL url = new URL(urlString)
            HttpURLConnection connection

            if (useProxy) {
                Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(ccHost, ccPort))
                connection = (HttpURLConnection) url.openConnection(proxy)
                connection.setRequestProperty("Proxy-Authorization", ccAuthHeader)
                connection.setRequestProperty("SAP-Connectivity-SCC-Location_ID", locationId)
            } else {
                connection = (HttpURLConnection) url.openConnection()
            }

            connection.setRequestMethod("POST")
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Authorization", elkAuthHeader)
            connection.setDoOutput(true)

            connection.outputStream.withWriter { writer ->
                writer.write(payload)
            }

            int responseCode = connection.responseCode
            println("Response Code: ${responseCode}")

            if (responseCode == HttpURLConnection.HTTP_OK) {
                connection.inputStream.withReader { reader ->
                    println("Response: ${reader.text}")
                }
            } else {
                println("POST request failed with response code: ${responseCode}")
            }
        } catch (Exception e) {
            e.printStackTrace()
        }
    }
}

def Message logElk(String level, String logF, Message message) {
    CloudConnectorContext context = new CloudConnectorContext()
    context.connectionType = ConnectionType.HTTP
    CloudConnectorProperties cloudConnectorProperties = ITApiFactory.getService(CloudConnectorProperties.class, context)

    String ccHost = cloudConnectorProperties.proxyHost
    int ccPort = cloudConnectorProperties.proxyPort
    String ccAuthHeader = cloudConnectorProperties.additionalHeaders["Proxy-Authorization"] ?: ""

    String messageHistories = message.getProperty("CamelMessageHistory").join(',')
    String lastCallActivity = messageHistories.substring(messageHistories.lastIndexOf("CallActivity"))
    String activity = lastCallActivity.substring(0, lastCallActivity.indexOf("]"))

    List<Map<String, String>> headersList = message.headers.collect { key, value -> [key: key, value: value.toString()] }
    List<Map<String, String>> propertiesList = message.properties.collect { key, value -> [key: key, value: value.toString()] }

    boolean useProxy = message.properties["ELK_PROXYTYPE"] == "On-Premise"
    String locationId = message.properties["ELK_LOCATION_ID"]

    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
    sdf.setTimeZone(TimeZone.getTimeZone("Europe/Madrid"))
    String timestamp = sdf.format(new Date())
    
    Map<String, Object> logstashBody = [
        "@metadata": [
            beat: "CloudIntegrationIflow",
            version: "1.0.0",
             "@timestamp": new Date().format("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'")
        ],
        iflow_id: message.exchange.context.name,
        is_tenant_name: "ap-corp-int-suite-des-slhbtbdx",
        btp_subaccount_id: "8cd58132-f002-4402-ac1e-899e7c4a805a",
        logs: [
            level: level,
            step: activity,
            logFuncional: logF,
            messageBody: message.getBody(String),
            messageProperties: propertiesList,
            messageHeaders: headersList,
            SAP_Sender: message.headers["SAP_Sender"],
            SAP_Receiver: message.headers["SAP_Receiver"],
            SAP_MessageType: message.headers["SAP_MessageType"],
            SAP_MessageProcessingLogID: message.properties["SAP_MessageProcessingLogID"],
            SAP_MPL_LogLevel_Overall: message.properties["SAP_MPL_LogLevel_Overall"],
            SAP_RunId: message.properties["SAP_RunId"],
            SAP_ApplicationID: message.headers["SAP_RunId"],
            SAP_MplCorrelationId: message.headers["SAP_MplCorrelationId"]
        ]
    ]

    String logstashUrl = message.properties["ELK_ENDPOINT"]
    SecureStoreService service = ITApiFactory.getApi(SecureStoreService.class, null)
    String auth = message.properties["ELK_AUTH"]
    def credential = service.getUserCredential(auth)

    if (credential == null) {
        throw new IllegalStateException("No ELK credential found")
    }

    String authHeader = "Basic " + "${credential.username}:${new String(credential.password)}".bytes.encodeBase64().toString()
    makeAsyncPostRequest(useProxy, logstashUrl, new JsonBuilder(logstashBody).toString(), authHeader, ccAuthHeader, locationId, ccHost, ccPort)

    return message
}
