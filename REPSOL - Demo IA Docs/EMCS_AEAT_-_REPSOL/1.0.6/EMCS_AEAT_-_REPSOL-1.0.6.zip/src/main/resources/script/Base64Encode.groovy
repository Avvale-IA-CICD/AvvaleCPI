import com.sap.it.api.mapping.*;
import java.util.Base64

def String encodeBase64(String value) {
    return Base64.getEncoder().encodeToString(value.getBytes("UTF-8"))
}


