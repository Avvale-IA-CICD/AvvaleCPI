import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*;

def Message processData(Message message) {
    // Obtener el valor del header ObjectID
    def objectID = message.getHeader("ObjectID", String)
    
    // Obtener el mensaje log
    def messageLog = messageLogFactory.getMessageLog(message);
    if(messageLog != null) {
        // Añadir custom headers
        messageLog.addCustomHeaderProperty("STEP", "BAPIRET2");
		def headers = message.getHeaders()
        def IdocIn = headers.get("IdocIn")
	    def InvoiceNumber = headers.get("InvoiceNumber")
		if (IdocIn != null) {
        messageLog.addCustomHeaderProperty("IdocIn", IdocIn)
    }
        if (InvoiceNumber != null) {
        messageLog.addCustomHeaderProperty("InvoiceNumber", InvoiceNumber)
    }        
        // Añadir el Custom header ObjectID al mensaje log
        if(objectID != null) {
            messageLog.addCustomHeaderProperty("DocumentID", objectID);
        } else {
            
            messageLog.addCustomHeaderProperty("DocumentID", "No ObjectID found");
        }  
    }
    return message;
}
