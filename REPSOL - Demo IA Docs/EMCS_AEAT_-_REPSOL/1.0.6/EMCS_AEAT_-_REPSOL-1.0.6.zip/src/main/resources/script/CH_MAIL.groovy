import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		messageLog.addCustomHeaderProperty("STEP", "Envio Factura Mail");
		def headers = message.getHeaders()
        def IdocIn = headers.get("IdocIn")
	    def InvoiceNumber = headers.get("InvoiceNumber")
		if (IdocIn != null) {
        messageLog.addCustomHeaderProperty("IdocIn", IdocIn)
        messageLog.addCustomHeaderProperty("Archivado", "OK");
    }
        if (InvoiceNumber != null) {
        messageLog.addCustomHeaderProperty("InvoiceNumber", InvoiceNumber)
    }
	}
	    
	return message;
}