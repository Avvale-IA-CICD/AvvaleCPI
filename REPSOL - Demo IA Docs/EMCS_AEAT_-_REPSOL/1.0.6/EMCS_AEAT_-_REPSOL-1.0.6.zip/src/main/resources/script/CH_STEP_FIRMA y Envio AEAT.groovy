import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
		messageLog.addCustomHeaderProperty("STEP", "Firma y Envio AEAT");
        
	}
	return message;
}