import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {
	
	def body =  message.getBody(String.class);
	def rootxml = new XmlSlurper().parseText(body);  
	def ediDc40Node = rootxml.'**'.find { it.name() == 'EDI_DC40' }
    def idocNum = ediDc40Node?.DOCNUM?.text()
	def SNDPRN = ediDc40Node?.SNDPRN?.text()
	def messageLog = messageLogFactory.getMessageLog(message);
	if((messageLog != null) && (idocNum != null)){
		messageLog.addCustomHeaderProperty("IDocIn", idocNum);
		messageLog.addCustomHeaderProperty("SNDPRN", SNDPRN);
		messageLog.addCustomHeaderProperty("STEP", "Firma");
	}
	return message;
}