import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {
	
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
    		messageLog.addCustomHeaderProperty("STEP", "Archivar Documentum");
    	if (message.getHeader("DN", String)) {
            messageLog.addCustomHeaderProperty("DN", message.getHeader("DN", String))
        }
        if (message.getHeader("acronimo", String)) {
            messageLog.addCustomHeaderProperty("Acronimo", message.getHeader("acronimo", String))
        }
        if (message.getHeader("aliasCertAutenticacion", String)) {
            messageLog.addCustomHeaderProperty("AliasCertAutenticacion", message.getHeader("aliasCertAutenticacion", String))
        }
        if (message.getHeader("GUID", String)) {
            messageLog.addCustomHeaderProperty("GUID", message.getHeader("GUID", String))
        }
        if (message.getHeader("NIFUppercase", String)) {
            messageLog.addCustomHeaderProperty("NIF", message.getHeader("NIFUppercase", String))
        }
        if (message.getHeader("IdCuenta", String)) {
            messageLog.addCustomHeaderProperty("IdCuenta", message.getHeader("idCuenta", String))
        }
	}
	return message;
}