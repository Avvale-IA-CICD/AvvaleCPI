import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap

def Message processData(Message message) {
    def headers = message.getHeaders()
    def properties = new HashMap<String, Object>()
    headers.each { key, value ->
        properties.put(key, value)
    }
    message.setProperties(properties)
    return message
}
