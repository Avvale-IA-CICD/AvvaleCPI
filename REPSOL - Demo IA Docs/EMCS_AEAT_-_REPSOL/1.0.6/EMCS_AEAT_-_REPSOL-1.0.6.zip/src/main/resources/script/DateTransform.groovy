import com.sap.gateway.ip.core.customdev.util.Message
import groovy.xml.XmlUtil

def Message processData(Message message) {
    // Obtener el cuerpo del mensaje como String
    def body = message.getBody(String)

    // Parsear el XML
    def xml = new XmlSlurper().parseText(body)

    // Buscar todos los elementos <ns2:properties>
    xml.'**'.findAll { it.name() == 'properties' }.each { propertyNode ->
        // Obtener el valor de <ns2:name>
        def nameValue = propertyNode.name.text()

        // Verificar si el nombre contiene "fech"
        if (nameValue.contains('fech')) {
            // Obtener el valor actual de <ns2:value>
            def currentValue = propertyNode.value.text()

            // Verificar si el valor sigue el patrón YYYYMMDD
            if (currentValue ==~ /^\d{8}$/) {
                // Transformar el valor de YYYYMMDD a DD/MM/YYYY
                def transformedValue = currentValue.replaceAll(/(\d{4})(\d{2})(\d{2})/, '$3/$2/$1')
                
                // Actualizar el valor en el XML
                propertyNode.value = transformedValue
            }
        }
    }

    // Convertir el XML actualizado a String
    def transformedXml = XmlUtil.serialize(xml)
    
    // Establecer el cuerpo del mensaje actualizado
    message.setBody(transformedXml)
    
    return message
}
