import com.sap.gateway.ip.core.customdev.util.Message
import java.util.HashMap
import groovy.xml.*

def Message processData(Message message) {
    // Obtener el cuerpo del mensaje
    def body = message.getBody(java.lang.String) as String

    // Parsear el XML
    def parser = new XmlParser().parseText(body)

    // Variables para los headers
    def objectId = null
    def errorCode = null
    def errorMsgId = null

    // Buscar el campo r_object_id
    def rObjectIdNode = parser.'**'.find { it.name().localPart == 'r_object_id' }?.text()

    def messageLog = messageLogFactory.getMessageLog(message)
    if (messageLog != null) {
        if (rObjectIdNode) {
            objectId = rObjectIdNode
            message.setHeader("ObjectID", objectId)
            messageLog.addCustomHeaderProperty("ObjectID", objectId)
        } else {
            def errorCodeNode = parser.'**'.find { it.name().localPart == 'errorCode' }?.text()
            def errorMessageNode = parser.'**'.find { it.name().localPart == 'errorMessage' }?.text()
            if (errorCodeNode) {
                errorCode = errorCodeNode
                message.setHeader("ErrorCode", errorCode)
                messageLog.addCustomHeaderProperty("ErrorCode", errorCode)
            }
            if (errorMessageNode) {
                def msgIdMatcher = errorMessageNode =~ /MsgId: (\S+)/
                if (msgIdMatcher) {
                    errorMsgId = msgIdMatcher[0][1]
                    message.setHeader("ErrorMsgIdDocumentum", errorMsgId)
                    messageLog.addCustomHeaderProperty("ErrorMsgIdDocumentum", errorMsgId)
                }
            }
        }
    }

    return message
}
