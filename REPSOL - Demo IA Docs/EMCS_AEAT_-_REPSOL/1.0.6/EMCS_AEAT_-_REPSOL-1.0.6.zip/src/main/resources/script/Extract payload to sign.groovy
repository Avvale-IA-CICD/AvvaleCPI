import com.sap.gateway.ip.core.customdev.util.Message
import com.sap.it.api.*
import groovy.xml.*
import com.sap.it.api.ITApiFactory
import com.sap.it.api.mapping.ValueMappingApi

def Message processData(Message message) {
    
    def valueMapApi = ITApiFactory.getApi(ValueMappingApi.class, null)
    def messageLog = messageLogFactory.getMessageLog(message)
    
    def body = message.getBody(String.class)
    def xml = new XmlSlurper().parseText(body)
    def NodeNif = xml.'**'.find { it.name() == "Header" }
    def NIFUppercase = NodeNif?.MessageSender?.text()
    def NIF = NodeNif?.MessageSender?.text().toLowerCase()
    def cd815a = xml.'**'.find { it.name() == "CD815A" }
    def cd815aXml = XmlUtil.serialize(cd815a)
    message.setBody(cd815aXml)
    def certData = xml.'**'.find { it.name() == "certData" }
    def aliasCertFirma = certData?.aliasCertFirma?.text()
    def aliasAppFirma = certData?.aliasAppFirma?.text()
    def aliasCertAutenticacion = certData?.aliasCertAutenticacion?.text()
    def guidData = xml.'**'.find { it.name() == "guidData" }
    def guid = guidData?.guid?.text()
    def idCuenta = guidData?.idCuenta?.text()
    def distinguishedName = valueMapApi.getMappedValue('BUSINESS', 'ACRONYM', aliasAppFirma, 'SIA', 'DN')
    if (aliasCertFirma) {
        message.setHeader("aliasCertFirma", aliasCertFirma)
        
    }

    if (aliasAppFirma) {
        message.setHeader("acronimo", aliasAppFirma)
        messageLog.addCustomHeaderProperty("Acronimo", aliasAppFirma)
        if (distinguishedName) {
            message.setHeader("DN", distinguishedName)
            messageLog.addCustomHeaderProperty("DN", distinguishedName)
        }
    }
    if (aliasCertAutenticacion) {
        message.setHeader("aliasCertAutenticacion", aliasCertAutenticacion)
        messageLog.addCustomHeaderProperty("AliasCertAutenticacion", aliasCertAutenticacion)
    }
    if (NIF) {
        message.setHeader("NIF", NIF)
    }
    if (NIFUppercase) {
        message.setHeader("NIFUppercase", NIFUppercase)
        messageLog.addCustomHeaderProperty("NIF", NIFUppercase)
    }
    if (guid) {
        message.setHeader("GUID", guid)
        messageLog.addCustomHeaderProperty("GUID", guid)
    }
    if (idCuenta) {
        message.setHeader("IdCuenta", idCuenta)
        messageLog.addCustomHeaderProperty("IdCuenta", idCuenta)
    }
    return message
}

