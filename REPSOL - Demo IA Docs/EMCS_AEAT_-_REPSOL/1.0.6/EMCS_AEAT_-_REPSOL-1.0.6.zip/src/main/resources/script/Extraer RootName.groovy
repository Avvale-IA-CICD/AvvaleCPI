import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import groovy.xml.*

def Message processData(Message message) {
	def body = message.getBody(String)
	def xml = new XmlSlurper().parseText(body)
	def rootTagName = xml.name()
	def messageLog = messageLogFactory.getMessageLog(message);
	if(messageLog != null){
    message.setHeader("ResponseTagName", rootTagName)
        messageLog.addCustomHeaderProperty("ResponseTagName", rootTagName)
	}
	return message;
}