import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    // Obtener todas las variables de entorno como headers
    def envVariables = System.getenv()
    envVariables.each { key, value ->
        message.setHeader(key, value)
    }

    // Obtener todas las propiedades del mensaje como headers
    def messageProperties = message.getProperties()
    messageProperties.each { key, value ->
        message.setHeader(key, value.toString())
    }
    
    return message
}
