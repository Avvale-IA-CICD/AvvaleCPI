import com.sap.it.api.mapping.*;
def String MailFrom(String input) {
    // Dividir la cadena por los dos puntos
    def parts = input.split(":")
    
    // Verificar que haya al menos 4 campos
    if (parts.size() >= 4) {
        // Devolver el cuarto campo (índice 3)
        return parts[3]
    } else {
        throw new IllegalArgumentException("La cadena de entrada no tiene suficientes campos")
    }
}
def String MailTo(String input) {
    // Dividir la cadena por los dos puntos
    def parts = input.split(":")
    
    // Verificar que haya al menos 4 campos
    if (parts.size() >= 6) {
        // Devolver el cuarto campo (índice 3)
        return parts[5]
    } else {
        throw new IllegalArgumentException("La cadena de entrada no tiene suficientes campos")
    }
}
def String MailCC(String input) {
    // Dividir la cadena por los dos puntos
    def parts = input.split(":")
    
    // Verificar que haya al menos 4 campos
    if (parts.size() >= 8) {
        // Devolver el cuarto campo (índice 3)
        return parts[7]
    }
}