import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.text.SimpleDateFormat;
import java.util.Date;

//Log Devolciones Pepsico
def Message log01(Message message) {processData("Log payload origen", message);}
def Message log02(Message message) {processData("Log respuesta SAP", message);}
def Message logError(Message message) {processData("LogError", message);}

def Message processData(String prefix, Message message) {
	def headers = message.getHeaders();
	def body = message.getBody(java.lang.String) as String;
	def messageLog = messageLogFactory.getMessageLog(message);
	for (header in headers) {
	   messageLog.setStringProperty("header." + header.getKey().toString(), header.getValue().toString())
	}
	for (property in properties) {
	   messageLog.setStringProperty("property." + property.getKey().toString(), property.getValue().toString())
	}
    if(messageLog != null){
        messageLog.addAttachmentAsString(prefix, body, "text/plain");
     }
    return message;
}