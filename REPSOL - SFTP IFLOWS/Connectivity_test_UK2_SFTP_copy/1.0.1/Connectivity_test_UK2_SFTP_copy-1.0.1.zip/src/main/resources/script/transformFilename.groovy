import com.sap.gateway.ip.core.customdev.util.Message
import java.text.SimpleDateFormat
import java.util.Date

def Message processData(Message message) {
    // Obtener el nombre del archivo del encabezado (header)
    def filename = message.getHeader("CamelFileName", String)

    // Separar el nombre del archivo y la extensión
    def dotIndex = filename.lastIndexOf('.')
    def name = filename.substring(0, dotIndex)
    def extension = filename.substring(dotIndex)

    // Formatear la fecha actual
    def sdf = new SimpleDateFormat("yyyyMMdd")
    def currentDate = sdf.format(new Date())

    // Construir el nuevo nombre del archivo
    def newFilename = "${name}_${currentDate}${extension}"

    // Establecer el nuevo nombre del archivo en el encabezado (header)
    message.setHeader("CamelFileName", newFilename)

    // Devolver el mensaje modificado
    return message
}
